# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key =  '670958af02d929f203bb9ca4892f501cbd42673139bebe979dd3beb40c0e8cee7f4e4ab28e08210c59a8b406f543870792a4e1aa95d832509b51f9447eb90f60'
